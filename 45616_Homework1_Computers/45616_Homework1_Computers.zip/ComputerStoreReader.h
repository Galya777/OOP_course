#pragma once
class ComputerStoreReader
{

};

