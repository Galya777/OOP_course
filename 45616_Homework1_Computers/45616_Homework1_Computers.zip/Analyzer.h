#pragma once
class Analyzer
{

};

