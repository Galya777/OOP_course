#include <iostream>
#include "PlayerCollection.h"
#pragma warning(disable:4996)
int main()
{
  /*  PlayerCollection players;
	for (size_t i = 0; i < players.playersCount() -1; i++)
	{
		for (size_t i = 1; i < players.playersCount(); i++)
		{
			
		}
	}*/
    return 0;
}

