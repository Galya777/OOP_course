#include "library.h"
#include "Publishing.h"
#include <iostream>
#include <cstring>

Library::Library() : numPublications(0), maxPublications(5), numReaders(0), maxReaders(5) {
    publications = new Publishing * [maxPublications];
    readers = new User* [maxReaders];
}

Library::~Library() {
    for (int i = 0; i < numPublications; i++) {
        delete publications[i];
    }
    delete[] publications;

    for (int i = 0; i < numReaders; i++) {
        delete readers[i];
    }
    delete[] readers;
}